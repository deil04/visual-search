﻿/********************* 
 * Corsi_Blocks *
 *********************/


// store info about the experiment session:
let expName = 'corsi_blocks';  // from the Builder filename that created this script
let expInfo = {
    'participant': `${util.pad(Number.parseFloat(util.randint(0, 999999)).toFixed(0), 6)}`,
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: false,
  color: new util.Color([1.0, 1.0, 1.0]),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); },flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(instructions_tRoutineBegin());
flowScheduler.add(instructions_tRoutineEachFrame());
flowScheduler.add(instructions_tRoutineEnd());
flowScheduler.add(countdownRoutineBegin());
flowScheduler.add(countdownRoutineEachFrame());
flowScheduler.add(countdownRoutineEnd());
const trials_tLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_tLoopBegin(trials_tLoopScheduler));
flowScheduler.add(trials_tLoopScheduler);
flowScheduler.add(trials_tLoopEnd);




flowScheduler.add(instructionsRoutineBegin());
flowScheduler.add(instructionsRoutineEachFrame());
flowScheduler.add(instructionsRoutineEnd());
flowScheduler.add(countdownRoutineBegin());
flowScheduler.add(countdownRoutineEachFrame());
flowScheduler.add(countdownRoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);




flowScheduler.add(endRoutineBegin());
flowScheduler.add(endRoutineEachFrame());
flowScheduler.add(endRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // resources:
    {'name': 'conditions1.csv', 'path': 'conditions1.csv'},
    {'name': 'conditions1.csv', 'path': 'conditions1.csv'},
    {'name': 'Images/Yes.png', 'path': 'Images/Yes.png'},
    {'name': 'Images/No.png', 'path': 'Images/No.png'},
    {'name': 'Images/1.png', 'path': 'Images/1.png'},
    {'name': 'Images/2.png', 'path': 'Images/2.png'},
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2024.2.4';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var instructions_tClock;
var mouse_instructions_t;
var text_instructions_t;
var countdownClock;
var text_3;
var text_2;
var text_1;
var ISIClock;
var blank;
var visual_search_tClock;
var square_t;
var instruct_t;
var mouse_t;
var target_t;
var C_t;
var InC_t;
var image_t;
var feedback_tClock;
var fb;
var trial_counter_2;
var rts;
var n_round;
var FB;
var instructionsClock;
var text_instructions;
var mouse_instructions;
var corsi_presentClock;
var square;
var instruct;
var mouse;
var target;
var C;
var InC;
var image;
var feedbackClock;
var fb_2;
var trial_counter;
var n_round_1;
var FB_2;
var endClock;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "instructions_t"
  instructions_tClock = new util.Clock();
  mouse_instructions_t = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_instructions_t.mouseClock = new util.Clock();
  text_instructions_t = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_instructions_t',
    text: 'คุณจะเห็นรูปทรงหลายรูปปรากฏบนหน้าจอในแต่ละรอบ\nคุณต้องหา "สามเหลี่ยม" เมื่อเจอให้กดปุ่มสึเขียว\nถ้าไม่มี "สามเหลี่ยม" ให้กดปุ่มสีแดง\nแตะเพื่อดำเนินการต่อ',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "countdown"
  countdownClock = new util.Clock();
  text_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_3',
    text: '3',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.2,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_2',
    text: '2',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.2,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  text_1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_1',
    text: '1',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.2,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "ISI"
  ISIClock = new util.Clock();
  blank = new visual.TextStim({
    win: psychoJS.window,
    name: 'blank',
    text: '+',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.2,  wrapWidth: undefined, ori: 0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: 1,
    depth: 0.0 
  });
  
  // Initialize components for Routine "visual_search_t"
  visual_search_tClock = new util.Clock();
  square_t = new visual.Rect ({
    win: psychoJS.window, name: 'square_t', 
    width: [0.6, 0.6][0], height: [0.6, 0.6][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: 0, 
    interpolate: true, 
  });
  
  instruct_t = new visual.TextStim({
    win: psychoJS.window,
    name: 'instruct_t',
    text: 'มีสามเหลี่ยมสีฟ้า     หรือไม่',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.4], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  mouse_t = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_t.mouseClock = new util.Clock();
  target_t = new visual.ShapeStim ({
    win: psychoJS.window, name: 'target_t', 
    vertices: [[-[0.039, 0.035][0]/2.0, -[0.039, 0.035][1]/2.0], [+[0.039, 0.035][0]/2.0, -[0.039, 0.035][1]/2.0], [0, [0.039, 0.035][1]/2.0]],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    fillColor: new util.Color([(- 1.0), 0.5059, 1.0]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -4, 
    interpolate: true, 
  });
  
  C_t = new visual.ImageStim({
    win : psychoJS.window,
    name : 'C_t', units : undefined, 
    image : 'Images/Yes.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [0.15, (- 0.4)], 
    draggable: false,
    size : [0.15, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -5.0 
  });
  InC_t = new visual.ImageStim({
    win : psychoJS.window,
    name : 'InC_t', units : undefined, 
    image : 'Images/No.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [(- 0.15), (- 0.4)], 
    draggable: false,
    size : [0.15, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -6.0 
  });
  image_t = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_t', units : undefined, 
    image : 'Images/1.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [0.1, 0.395], 
    draggable: false,
    size : [0.07, 0.07],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -7.0 
  });
  // Initialize components for Routine "feedback_t"
  feedback_tClock = new util.Clock();
  fb = new visual.TextStim({
    win: psychoJS.window,
    name: 'fb',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  trial_counter_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'trial_counter_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Run 'Begin Experiment' code from track_rt
  rts = [];
  n_round = 0;
  
  FB = new visual.TextStim({
    win: psychoJS.window,
    name: 'FB',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.06], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: -3.0 
  });
  
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  text_instructions = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_instructions',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  mouse_instructions = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_instructions.mouseClock = new util.Clock();
  // Initialize components for Routine "corsi_present"
  corsi_presentClock = new util.Clock();
  square = new visual.Rect ({
    win: psychoJS.window, name: 'square', 
    width: [0.6, 0.6][0], height: [0.6, 0.6][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    fillColor: new util.Color([1.0, 1.0, 1.0]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: 0, 
    interpolate: true, 
  });
  
  instruct = new visual.TextStim({
    win: psychoJS.window,
    name: 'instruct',
    text: 'มีสามเหลี่ยม     หรือไม่',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.4], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  mouse = new core.Mouse({
    win: psychoJS.window,
  });
  mouse.mouseClock = new util.Clock();
  target = new visual.ShapeStim ({
    win: psychoJS.window, name: 'target', 
    vertices: [[-[0.039, 0.035][0]/2.0, -[0.039, 0.035][1]/2.0], [+[0.039, 0.035][0]/2.0, -[0.039, 0.035][1]/2.0], [0, [0.039, 0.035][1]/2.0]],
    ori: 0.0, 
    pos: [10, 10], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('grey'), 
    fillColor: new util.Color('grey'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -4, 
    interpolate: true, 
  });
  
  C = new visual.ImageStim({
    win : psychoJS.window,
    name : 'C', units : undefined, 
    image : 'Images/Yes.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [0.15, (- 0.4)], 
    draggable: false,
    size : [0.15, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -5.0 
  });
  InC = new visual.ImageStim({
    win : psychoJS.window,
    name : 'InC', units : undefined, 
    image : 'Images/No.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [(- 0.15), (- 0.4)], 
    draggable: false,
    size : [0.15, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -6.0 
  });
  image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image', units : undefined, 
    image : 'Images/2.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [0.055, 0.395], 
    draggable: false,
    size : [0.07, 0.07],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -7.0 
  });
  // Initialize components for Routine "feedback"
  feedbackClock = new util.Clock();
  fb_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'fb_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  trial_counter = new visual.TextStim({
    win: psychoJS.window,
    name: 'trial_counter',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Run 'Begin Experiment' code from track_rt_2
  rts = [];
  n_round_1 = 0;
  
  FB_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'FB_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.06], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: -3.0 
  });
  
  // Initialize components for Routine "end"
  endClock = new util.Clock();
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var instructions_tMaxDurationReached;
var gotValidClick;
var instructions_tMaxDuration;
var instructions_tComponents;
function instructions_tRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions_t' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    instructions_tClock.reset();
    routineTimer.reset();
    instructions_tMaxDurationReached = false;
    // update component parameters for each repeat
    // setup some python lists for storing info about the mouse_instructions_t
    gotValidClick = false; // until a click is received
    instructions_tMaxDuration = null
    // keep track of which components have finished
    instructions_tComponents = [];
    instructions_tComponents.push(mouse_instructions_t);
    instructions_tComponents.push(text_instructions_t);
    
    instructions_tComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var prevButtonState;
var _mouseButtons;
function instructions_tRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions_t' ---
    // get current time
    t = instructions_tClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // *mouse_instructions_t* updates
    if (t >= 0.0 && mouse_instructions_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_instructions_t.tStart = t;  // (not accounting for frame time here)
      mouse_instructions_t.frameNStart = frameN;  // exact frame index
      
      mouse_instructions_t.status = PsychoJS.Status.STARTED;
      mouse_instructions_t.mouseClock.reset();
      prevButtonState = mouse_instructions_t.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_instructions_t.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_instructions_t.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // end routine on response
          continueRoutine = false;
        }
      }
    }
    
    // *text_instructions_t* updates
    if (t >= 0.0 && text_instructions_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_instructions_t.tStart = t;  // (not accounting for frame time here)
      text_instructions_t.frameNStart = frameN;  // exact frame index
      
      text_instructions_t.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instructions_tComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructions_tRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions_t' ---
    instructions_tComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // store data for psychoJS.experiment (ExperimentHandler)
    // the Routine "instructions_t" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var countdownMaxDurationReached;
var countdownMaxDuration;
var countdownComponents;
function countdownRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'countdown' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    countdownClock.reset(routineTimer.getTime());
    routineTimer.add(3.000000);
    countdownMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('countdown.started', globalClock.getTime());
    countdownMaxDuration = null
    // keep track of which components have finished
    countdownComponents = [];
    countdownComponents.push(text_3);
    countdownComponents.push(text_2);
    countdownComponents.push(text_1);
    
    countdownComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function countdownRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'countdown' ---
    // get current time
    t = countdownClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text_3* updates
    if (t >= 0.0 && text_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_3.tStart = t;  // (not accounting for frame time here)
      text_3.frameNStart = frameN;  // exact frame index
      
      text_3.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (text_3.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text_3.setAutoDraw(false);
    }
    
    
    // *text_2* updates
    if (t >= 1.0 && text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_2.tStart = t;  // (not accounting for frame time here)
      text_2.frameNStart = frameN;  // exact frame index
      
      text_2.setAutoDraw(true);
    }
    
    frameRemains = 1.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (text_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text_2.setAutoDraw(false);
    }
    
    
    // *text_1* updates
    if (t >= 2.0 && text_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_1.tStart = t;  // (not accounting for frame time here)
      text_1.frameNStart = frameN;  // exact frame index
      
      text_1.setAutoDraw(true);
    }
    
    frameRemains = 2.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (text_1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text_1.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    countdownComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function countdownRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'countdown' ---
    countdownComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('countdown.stopped', globalClock.getTime());
    if (countdownMaxDurationReached) {
        countdownClock.add(countdownMaxDuration);
    } else {
        countdownClock.add(3.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var trials_t;
function trials_tLoopBegin(trials_tLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_t = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'conditions1.csv',
      seed: undefined, name: 'trials_t'
    });
    psychoJS.experiment.addLoop(trials_t); // add the loop to the experiment
    currentLoop = trials_t;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials_t.forEach(function() {
      snapshot = trials_t.getSnapshot();
    
      trials_tLoopScheduler.add(importConditions(snapshot));
      trials_tLoopScheduler.add(ISIRoutineBegin(snapshot));
      trials_tLoopScheduler.add(ISIRoutineEachFrame());
      trials_tLoopScheduler.add(ISIRoutineEnd(snapshot));
      trials_tLoopScheduler.add(visual_search_tRoutineBegin(snapshot));
      trials_tLoopScheduler.add(visual_search_tRoutineEachFrame());
      trials_tLoopScheduler.add(visual_search_tRoutineEnd(snapshot));
      trials_tLoopScheduler.add(feedback_tRoutineBegin(snapshot));
      trials_tLoopScheduler.add(feedback_tRoutineEachFrame());
      trials_tLoopScheduler.add(feedback_tRoutineEnd(snapshot));
      trials_tLoopScheduler.add(trials_tLoopEndIteration(trials_tLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_tLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_t);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_tLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'conditions1.csv',
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials.forEach(function() {
      snapshot = trials.getSnapshot();
    
      trialsLoopScheduler.add(importConditions(snapshot));
      trialsLoopScheduler.add(ISIRoutineBegin(snapshot));
      trialsLoopScheduler.add(ISIRoutineEachFrame());
      trialsLoopScheduler.add(ISIRoutineEnd(snapshot));
      trialsLoopScheduler.add(corsi_presentRoutineBegin(snapshot));
      trialsLoopScheduler.add(corsi_presentRoutineEachFrame());
      trialsLoopScheduler.add(corsi_presentRoutineEnd(snapshot));
      trialsLoopScheduler.add(feedbackRoutineBegin(snapshot));
      trialsLoopScheduler.add(feedbackRoutineEachFrame());
      trialsLoopScheduler.add(feedbackRoutineEnd(snapshot));
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var ISIMaxDurationReached;
var ISIMaxDuration;
var ISIComponents;
function ISIRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'ISI' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    ISIClock.reset(routineTimer.getTime());
    routineTimer.add(0.500000);
    ISIMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('ISI.started', globalClock.getTime());
    ISIMaxDuration = null
    // keep track of which components have finished
    ISIComponents = [];
    ISIComponents.push(blank);
    
    ISIComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function ISIRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'ISI' ---
    // get current time
    t = ISIClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *blank* updates
    if (t >= 0.0 && blank.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      blank.tStart = t;  // (not accounting for frame time here)
      blank.frameNStart = frameN;  // exact frame index
      
      blank.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (blank.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      blank.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ISIComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ISIRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'ISI' ---
    ISIComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('ISI.stopped', globalClock.getTime());
    if (ISIMaxDurationReached) {
        ISIClock.add(ISIMaxDuration);
    } else {
        ISIClock.add(0.500000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var visual_search_tMaxDurationReached;
var n_distractors;
var n_target;
var distractors;
var targets;
var xys;
var count;
var positions;
var visual_search_tMaxDuration;
var visual_search_tComponents;
function visual_search_tRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'visual_search_t' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    visual_search_tClock.reset();
    routineTimer.reset();
    visual_search_tMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_t
    n_distractors = decoy;
    n_target = tar;
    distractors = [];
    targets = [];
    xys = [[(- 0.25), (- 0.25)], [(- 0.194444), (- 0.25)], [(- 0.138889), (- 0.25)], [(- 0.083333), (- 0.25)], [(- 0.027778), (- 0.25)], [0.027778, (- 0.25)], [0.083333, (- 0.25)], [0.138889, (- 0.25)], [0.194444, (- 0.25)], [0.25, (- 0.25)], [(- 0.25), (- 0.194444)], [(- 0.194444), (- 0.194444)], [(- 0.138889), (- 0.194444)], [(- 0.083333), (- 0.194444)], [(- 0.027778), (- 0.194444)], [0.027778, (- 0.194444)], [0.083333, (- 0.194444)], [0.138889, (- 0.194444)], [0.194444, (- 0.194444)], [0.25, (- 0.194444)], [(- 0.25), (- 0.138889)], [(- 0.194444), (- 0.138889)], [(- 0.138889), (- 0.138889)], [(- 0.083333), (- 0.138889)], [(- 0.027778), (- 0.138889)], [0.027778, (- 0.138889)], [0.083333, (- 0.138889)], [0.138889, (- 0.138889)], [0.194444, (- 0.138889)], [0.25, (- 0.138889)], [(- 0.25), (- 0.083333)], [(- 0.194444), (- 0.083333)], [(- 0.138889), (- 0.083333)], [(- 0.083333), (- 0.083333)], [(- 0.027778), (- 0.083333)], [0.027778, (- 0.083333)], [0.083333, (- 0.083333)], [0.138889, (- 0.083333)], [0.194444, (- 0.083333)], [0.25, (- 0.083333)], [(- 0.25), (- 0.027778)], [(- 0.194444), (- 0.027778)], [(- 0.138889), (- 0.027778)], [(- 0.083333), (- 0.027778)], [(- 0.027778), (- 0.027778)], [0.027778, (- 0.027778)], [0.083333, (- 0.027778)], [0.138889, (- 0.027778)], [0.194444, (- 0.027778)], [0.25, (- 0.027778)], [(- 0.25), 0.027778], [(- 0.194444), 0.027778], [(- 0.138889), 0.027778], [(- 0.083333), 0.027778], [(- 0.027778), 0.027778], [0.027778, 0.027778], [0.083333, 0.027778], [0.138889, 0.027778], [0.194444, 0.027778], [0.25, 0.027778], [(- 0.25), 0.083333], [(- 0.194444), 0.083333], [(- 0.138889), 0.083333], [(- 0.083333), 0.083333], [(- 0.027778), 0.083333], [0.027778, 0.083333], [0.083333, 0.083333], [0.138889, 0.083333], [0.194444, 0.083333], [0.25, 0.083333], [(- 0.25), 0.138889], [(- 0.194444), 0.138889], [(- 0.138889), 0.138889], [(- 0.083333), 0.138889], [(- 0.027778), 0.138889], [0.027778, 0.138889], [0.083333, 0.138889], [0.138889, 0.138889], [0.194444, 0.138889], [0.25, 0.138889], [(- 0.25), 0.194444], [(- 0.194444), 0.194444], [(- 0.138889), 0.194444], [(- 0.083333), 0.194444], [(- 0.027778), 0.194444], [0.027778, 0.194444], [0.083333, 0.194444], [0.138889, 0.194444], [0.194444, 0.194444], [0.25, 0.194444], [(- 0.25), 0.25], [(- 0.194444), 0.25], [(- 0.138889), 0.25], [(- 0.083333), 0.25], [(- 0.027778), 0.25], [0.027778, 0.25], [0.083333, 0.25], [0.138889, 0.25], [0.194444, 0.25], [0.25, 0.25]];
    util.shuffle(xys);
    count = 0;
    positions = [];
    for (var i, _pj_c = 0, _pj_a = util.range(n_distractors), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        i = _pj_a[_pj_c];
        distractor = new visual.Polygon({"win": psychoJS.window, "edges": 3, "size": 0.05, "pos": [xys[count][0], xys[count][1]], "lineColor": "yellow", "fillColor": "yellow", "opacity": 1.0, "depth": (- 1.0)});
        distractors.push(distractor);
        positions.push(xys[count]);
        count += 1;
    }
    for (var i, _pj_c = 0, _pj_a = util.range(n_target), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        i = _pj_a[_pj_c];
        target = new visual.Polygon({"win": psychoJS.window, "edges": 3, "size": 0.05, "pos": [xys[count][0], xys[count][1]], "lineColor": [(- 1.0), 0.2, 1.0], "fillColor": [(- 1.0), 0.2, 1.0], "opacity": 1.0, "depth": (- 1.0)});
        targets.push(target);
        positions.push(xys[count]);
    }
    for (var distractor, _pj_c = 0, _pj_a = distractors, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        distractor = _pj_a[_pj_c];
        distractor.setAutoDraw(true);
    }
    for (var target, _pj_c = 0, _pj_a = targets, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        target = _pj_a[_pj_c];
        target.setAutoDraw(true);
    }
    
    // setup some python lists for storing info about the mouse_t
    // current position of the mouse:
    mouse_t.x = [];
    mouse_t.y = [];
    mouse_t.leftButton = [];
    mouse_t.midButton = [];
    mouse_t.rightButton = [];
    mouse_t.time = [];
    mouse_t.clicked_name = [];
    gotValidClick = false; // until a click is received
    target_t.setPos([10, 10]);
    psychoJS.experiment.addData('visual_search_t.started', globalClock.getTime());
    visual_search_tMaxDuration = null
    // keep track of which components have finished
    visual_search_tComponents = [];
    visual_search_tComponents.push(square_t);
    visual_search_tComponents.push(instruct_t);
    visual_search_tComponents.push(mouse_t);
    visual_search_tComponents.push(target_t);
    visual_search_tComponents.push(C_t);
    visual_search_tComponents.push(InC_t);
    visual_search_tComponents.push(image_t);
    
    visual_search_tComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var _mouseXYs;
function visual_search_tRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'visual_search_t' ---
    // get current time
    t = visual_search_tClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *square_t* updates
    if (t >= 0.0 && square_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      square_t.tStart = t;  // (not accounting for frame time here)
      square_t.frameNStart = frameN;  // exact frame index
      
      square_t.setAutoDraw(true);
    }
    
    
    // *instruct_t* updates
    if (t >= 0.0 && instruct_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruct_t.tStart = t;  // (not accounting for frame time here)
      instruct_t.frameNStart = frameN;  // exact frame index
      
      instruct_t.setAutoDraw(true);
    }
    
    // *mouse_t* updates
    if (t >= 0.0 && mouse_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_t.tStart = t;  // (not accounting for frame time here)
      mouse_t.frameNStart = frameN;  // exact frame index
      
      mouse_t.status = PsychoJS.Status.STARTED;
      mouse_t.mouseClock.reset();
      prevButtonState = mouse_t.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_t.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_t.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          mouse_t.clickableObjects = eval([target_t, C_t, InC_t])
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(mouse_t.clickableObjects)) {
              mouse_t.clickableObjects = [mouse_t.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of mouse_t.clickableObjects) {
              if (obj.contains(mouse_t)) {
                  gotValidClick = true;
                  mouse_t.clicked_name.push(obj.name);
              }
          }
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          mouse_t.clickableObjects = eval([target_t, C_t, InC_t])
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(mouse_t.clickableObjects)) {
              mouse_t.clickableObjects = [mouse_t.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of mouse_t.clickableObjects) {
              if (obj.contains(mouse_t)) {
                  gotValidClick = true;
                  mouse_t.clicked_name.push(obj.name);
              }
          }
          if (gotValidClick === true) { 
            _mouseXYs = mouse_t.getPos();
            mouse_t.x.push(_mouseXYs[0]);
            mouse_t.y.push(_mouseXYs[1]);
            mouse_t.leftButton.push(_mouseButtons[0]);
            mouse_t.midButton.push(_mouseButtons[1]);
            mouse_t.rightButton.push(_mouseButtons[2]);
            mouse_t.time.push(mouse_t.mouseClock.getTime());
          }
          if (gotValidClick === true) { // end routine on response
            continueRoutine = false;
          }
        }
      }
    }
    
    // *target_t* updates
    if (t >= 0.0 && target_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target_t.tStart = t;  // (not accounting for frame time here)
      target_t.frameNStart = frameN;  // exact frame index
      
      target_t.setAutoDraw(true);
    }
    
    
    // *C_t* updates
    if (t >= 0.0 && C_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      C_t.tStart = t;  // (not accounting for frame time here)
      C_t.frameNStart = frameN;  // exact frame index
      
      C_t.setAutoDraw(true);
    }
    
    
    // *InC_t* updates
    if (t >= 0.0 && InC_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      InC_t.tStart = t;  // (not accounting for frame time here)
      InC_t.frameNStart = frameN;  // exact frame index
      
      InC_t.setAutoDraw(true);
    }
    
    
    // *image_t* updates
    if (t >= 0.0 && image_t.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_t.tStart = t;  // (not accounting for frame time here)
      image_t.frameNStart = frameN;  // exact frame index
      
      image_t.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    visual_search_tComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var correct;
function visual_search_tRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'visual_search_t' ---
    visual_search_tComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('visual_search_t.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_t
    if ((mouse_t.clicked_name.slice((- 1))[0] === corrAns_t)) {
        correct = 1;
    } else {
        correct = 0;
    }
    for (var distractor, _pj_c = 0, _pj_a = distractors, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        distractor = _pj_a[_pj_c];
        distractor.setAutoDraw(false);
    }
    for (var target, _pj_c = 0, _pj_a = targets, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        target = _pj_a[_pj_c];
        target.setAutoDraw(false);
    }
    
    // store data for psychoJS.experiment (ExperimentHandler)
    psychoJS.experiment.addData('mouse_t.x', mouse_t.x);
    psychoJS.experiment.addData('mouse_t.y', mouse_t.y);
    psychoJS.experiment.addData('mouse_t.leftButton', mouse_t.leftButton);
    psychoJS.experiment.addData('mouse_t.midButton', mouse_t.midButton);
    psychoJS.experiment.addData('mouse_t.rightButton', mouse_t.rightButton);
    psychoJS.experiment.addData('mouse_t.time', mouse_t.time);
    psychoJS.experiment.addData('mouse_t.clicked_name', mouse_t.clicked_name);
    
    // the Routine "visual_search_t" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var feedback_tMaxDurationReached;
var feedback_text;
var feedback_tMaxDuration;
var feedback_tComponents;
function feedback_tRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'feedback_t' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    feedback_tClock.reset(routineTimer.getTime());
    routineTimer.add(1.000000);
    feedback_tMaxDurationReached = false;
    // update component parameters for each repeat
    fb.setText((("\u0e04\u0e38\u0e13\u0e1e\u0e1a\u0e40\u0e1b\u0e49\u0e32\u0e2b\u0e21\u0e32\u0e22\u0e43\u0e19 " + Number.parseInt((mouse_t.time.slice((- 1))[0] * 1000)).toString()) + "ms"));
    trial_counter_2.setText(((trials_t.thisN.toString() + "/") + trials_t.nTotal.toString()));
    // Run 'Begin Routine' code from track_rt
    if ((correct === 1)) {
        feedback_text = "ถูกต้อง!";
    } else {
        if ((correct === 0)) {
            feedback_text = "ผิด!";
        }
    }
    FB.setText(feedback_text);
    feedback_tMaxDuration = null
    // keep track of which components have finished
    feedback_tComponents = [];
    feedback_tComponents.push(fb);
    feedback_tComponents.push(trial_counter_2);
    feedback_tComponents.push(FB);
    
    feedback_tComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function feedback_tRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'feedback_t' ---
    // get current time
    t = feedback_tClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fb* updates
    if (t >= 0.0 && fb.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fb.tStart = t;  // (not accounting for frame time here)
      fb.frameNStart = frameN;  // exact frame index
      
      fb.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (fb.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      fb.setAutoDraw(false);
    }
    
    
    // *trial_counter_2* updates
    if (t >= 0.0 && trial_counter_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      trial_counter_2.tStart = t;  // (not accounting for frame time here)
      trial_counter_2.frameNStart = frameN;  // exact frame index
      
      trial_counter_2.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (trial_counter_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      trial_counter_2.setAutoDraw(false);
    }
    
    
    // *FB* updates
    if (t >= 0.0 && FB.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      FB.tStart = t;  // (not accounting for frame time here)
      FB.frameNStart = frameN;  // exact frame index
      
      FB.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (FB.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      FB.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    feedback_tComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function feedback_tRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'feedback_t' ---
    feedback_tComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // Run 'End Routine' code from track_rt
    rts.push(mouse_t.time.slice((- 1))[0]);
    n_round += 1;
    if ((n_round > 1)) {
        trials_t.finished = true;
    }
    
    if (feedback_tMaxDurationReached) {
        feedback_tClock.add(feedback_tMaxDuration);
    } else {
        feedback_tClock.add(1.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var instructionsMaxDurationReached;
var instructionsMaxDuration;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    instructionsClock.reset();
    routineTimer.reset();
    instructionsMaxDurationReached = false;
    // update component parameters for each repeat
    text_instructions.setText('\nแตะหน้าจอเพื่อเริ่มเล่น');
    // setup some python lists for storing info about the mouse_instructions
    gotValidClick = false; // until a click is received
    instructionsMaxDuration = null
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(text_instructions);
    instructionsComponents.push(mouse_instructions);
    
    instructionsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instructionsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions' ---
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text_instructions* updates
    if (t >= 0.0 && text_instructions.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_instructions.tStart = t;  // (not accounting for frame time here)
      text_instructions.frameNStart = frameN;  // exact frame index
      
      text_instructions.setAutoDraw(true);
    }
    
    // *mouse_instructions* updates
    if (t >= 0.0 && mouse_instructions.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_instructions.tStart = t;  // (not accounting for frame time here)
      mouse_instructions.frameNStart = frameN;  // exact frame index
      
      mouse_instructions.status = PsychoJS.Status.STARTED;
      mouse_instructions.mouseClock.reset();
      prevButtonState = mouse_instructions.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_instructions.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_instructions.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // end routine on response
          continueRoutine = false;
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instructionsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructionsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions' ---
    instructionsComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // store data for psychoJS.experiment (ExperimentHandler)
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var corsi_presentMaxDurationReached;
var corsi_presentMaxDuration;
var corsi_presentComponents;
function corsi_presentRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'corsi_present' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    corsi_presentClock.reset();
    routineTimer.reset();
    corsi_presentMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code
    n_distractors = decoy;
    n_target = tar;
    distractors = [];
    targets = [];
    xys = [[(- 0.25), (- 0.25)], [(- 0.194444), (- 0.25)], [(- 0.138889), (- 0.25)], [(- 0.083333), (- 0.25)], [(- 0.027778), (- 0.25)], [0.027778, (- 0.25)], [0.083333, (- 0.25)], [0.138889, (- 0.25)], [0.194444, (- 0.25)], [0.25, (- 0.25)], [(- 0.25), (- 0.194444)], [(- 0.194444), (- 0.194444)], [(- 0.138889), (- 0.194444)], [(- 0.083333), (- 0.194444)], [(- 0.027778), (- 0.194444)], [0.027778, (- 0.194444)], [0.083333, (- 0.194444)], [0.138889, (- 0.194444)], [0.194444, (- 0.194444)], [0.25, (- 0.194444)], [(- 0.25), (- 0.138889)], [(- 0.194444), (- 0.138889)], [(- 0.138889), (- 0.138889)], [(- 0.083333), (- 0.138889)], [(- 0.027778), (- 0.138889)], [0.027778, (- 0.138889)], [0.083333, (- 0.138889)], [0.138889, (- 0.138889)], [0.194444, (- 0.138889)], [0.25, (- 0.138889)], [(- 0.25), (- 0.083333)], [(- 0.194444), (- 0.083333)], [(- 0.138889), (- 0.083333)], [(- 0.083333), (- 0.083333)], [(- 0.027778), (- 0.083333)], [0.027778, (- 0.083333)], [0.083333, (- 0.083333)], [0.138889, (- 0.083333)], [0.194444, (- 0.083333)], [0.25, (- 0.083333)], [(- 0.25), (- 0.027778)], [(- 0.194444), (- 0.027778)], [(- 0.138889), (- 0.027778)], [(- 0.083333), (- 0.027778)], [(- 0.027778), (- 0.027778)], [0.027778, (- 0.027778)], [0.083333, (- 0.027778)], [0.138889, (- 0.027778)], [0.194444, (- 0.027778)], [0.25, (- 0.027778)], [(- 0.25), 0.027778], [(- 0.194444), 0.027778], [(- 0.138889), 0.027778], [(- 0.083333), 0.027778], [(- 0.027778), 0.027778], [0.027778, 0.027778], [0.083333, 0.027778], [0.138889, 0.027778], [0.194444, 0.027778], [0.25, 0.027778], [(- 0.25), 0.083333], [(- 0.194444), 0.083333], [(- 0.138889), 0.083333], [(- 0.083333), 0.083333], [(- 0.027778), 0.083333], [0.027778, 0.083333], [0.083333, 0.083333], [0.138889, 0.083333], [0.194444, 0.083333], [0.25, 0.083333], [(- 0.25), 0.138889], [(- 0.194444), 0.138889], [(- 0.138889), 0.138889], [(- 0.083333), 0.138889], [(- 0.027778), 0.138889], [0.027778, 0.138889], [0.083333, 0.138889], [0.138889, 0.138889], [0.194444, 0.138889], [0.25, 0.138889], [(- 0.25), 0.194444], [(- 0.194444), 0.194444], [(- 0.138889), 0.194444], [(- 0.083333), 0.194444], [(- 0.027778), 0.194444], [0.027778, 0.194444], [0.083333, 0.194444], [0.138889, 0.194444], [0.194444, 0.194444], [0.25, 0.194444], [(- 0.25), 0.25], [(- 0.194444), 0.25], [(- 0.138889), 0.25], [(- 0.083333), 0.25], [(- 0.027778), 0.25], [0.027778, 0.25], [0.083333, 0.25], [0.138889, 0.25], [0.194444, 0.25], [0.25, 0.25]];
    util.shuffle(xys);
    count = 0;
    positions = [];
    for (var i, _pj_c = 0, _pj_a = util.range(n_distractors), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        i = _pj_a[_pj_c];
        distractor = new visual.Polygon({"win": psychoJS.window, "edges": 4, "size": 0.05, "pos": [xys[count][0], (xys[count][1] + 0.01)], "lineColor": "grey", "fillColor": "grey", "opacity": 1.0, "depth": (- 1.0), "ori": 45});
        distractors.push(distractor);
        positions.push(xys[count]);
        count += 1;
    }
    for (var i, _pj_c = 0, _pj_a = util.range(n_target), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        i = _pj_a[_pj_c];
        target = new visual.Polygon({"win": psychoJS.window, "edges": 3, "size": 0.05, "pos": [xys[count][0], xys[count][1]], "lineColor": "grey", "fillColor": "grey", "opacity": 1.0, "depth": (- 1.0)});
        targets.push(target);
        positions.push(xys[count]);
    }
    for (var distractor, _pj_c = 0, _pj_a = distractors, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        distractor = _pj_a[_pj_c];
        distractor.setAutoDraw(true);
    }
    for (var target, _pj_c = 0, _pj_a = targets, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        target = _pj_a[_pj_c];
        target.setAutoDraw(true);
    }
    
    // setup some python lists for storing info about the mouse
    // current position of the mouse:
    mouse.x = [];
    mouse.y = [];
    mouse.leftButton = [];
    mouse.midButton = [];
    mouse.rightButton = [];
    mouse.time = [];
    mouse.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('corsi_present.started', globalClock.getTime());
    corsi_presentMaxDuration = null
    // keep track of which components have finished
    corsi_presentComponents = [];
    corsi_presentComponents.push(square);
    corsi_presentComponents.push(instruct);
    corsi_presentComponents.push(mouse);
    corsi_presentComponents.push(target);
    corsi_presentComponents.push(C);
    corsi_presentComponents.push(InC);
    corsi_presentComponents.push(image);
    
    corsi_presentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function corsi_presentRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'corsi_present' ---
    // get current time
    t = corsi_presentClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *square* updates
    if (t >= 0.0 && square.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      square.tStart = t;  // (not accounting for frame time here)
      square.frameNStart = frameN;  // exact frame index
      
      square.setAutoDraw(true);
    }
    
    
    // *instruct* updates
    if (t >= 0.0 && instruct.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruct.tStart = t;  // (not accounting for frame time here)
      instruct.frameNStart = frameN;  // exact frame index
      
      instruct.setAutoDraw(true);
    }
    
    // *mouse* updates
    if (t >= 0.0 && mouse.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse.tStart = t;  // (not accounting for frame time here)
      mouse.frameNStart = frameN;  // exact frame index
      
      mouse.status = PsychoJS.Status.STARTED;
      mouse.mouseClock.reset();
      prevButtonState = mouse.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          mouse.clickableObjects = eval([target, C, InC])
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(mouse.clickableObjects)) {
              mouse.clickableObjects = [mouse.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of mouse.clickableObjects) {
              if (obj.contains(mouse)) {
                  gotValidClick = true;
                  mouse.clicked_name.push(obj.name);
              }
          }
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          mouse.clickableObjects = eval([target, C, InC])
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(mouse.clickableObjects)) {
              mouse.clickableObjects = [mouse.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of mouse.clickableObjects) {
              if (obj.contains(mouse)) {
                  gotValidClick = true;
                  mouse.clicked_name.push(obj.name);
              }
          }
          if (gotValidClick === true) { 
            _mouseXYs = mouse.getPos();
            mouse.x.push(_mouseXYs[0]);
            mouse.y.push(_mouseXYs[1]);
            mouse.leftButton.push(_mouseButtons[0]);
            mouse.midButton.push(_mouseButtons[1]);
            mouse.rightButton.push(_mouseButtons[2]);
            mouse.time.push(mouse.mouseClock.getTime());
          }
          if (gotValidClick === true) { // end routine on response
            continueRoutine = false;
          }
        }
      }
    }
    
    // *target* updates
    if (t >= 0.0 && target.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target.tStart = t;  // (not accounting for frame time here)
      target.frameNStart = frameN;  // exact frame index
      
      target.setAutoDraw(true);
    }
    
    
    // *C* updates
    if (t >= 0.0 && C.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      C.tStart = t;  // (not accounting for frame time here)
      C.frameNStart = frameN;  // exact frame index
      
      C.setAutoDraw(true);
    }
    
    
    // *InC* updates
    if (t >= 0.0 && InC.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      InC.tStart = t;  // (not accounting for frame time here)
      InC.frameNStart = frameN;  // exact frame index
      
      InC.setAutoDraw(true);
    }
    
    
    // *image* updates
    if (t >= 0.0 && image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image.tStart = t;  // (not accounting for frame time here)
      image.frameNStart = frameN;  // exact frame index
      
      image.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    corsi_presentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function corsi_presentRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'corsi_present' ---
    corsi_presentComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('corsi_present.stopped', globalClock.getTime());
    // Run 'End Routine' code from code
    if ((mouse.clicked_name.slice((- 1))[0] === corrAns)) {
        correct = 1;
    } else {
        correct = 0;
    }
    for (var distractor, _pj_c = 0, _pj_a = distractors, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        distractor = _pj_a[_pj_c];
        distractor.setAutoDraw(false);
    }
    for (var target, _pj_c = 0, _pj_a = targets, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        target = _pj_a[_pj_c];
        target.setAutoDraw(false);
    }
    
    // store data for psychoJS.experiment (ExperimentHandler)
    psychoJS.experiment.addData('mouse.x', mouse.x);
    psychoJS.experiment.addData('mouse.y', mouse.y);
    psychoJS.experiment.addData('mouse.leftButton', mouse.leftButton);
    psychoJS.experiment.addData('mouse.midButton', mouse.midButton);
    psychoJS.experiment.addData('mouse.rightButton', mouse.rightButton);
    psychoJS.experiment.addData('mouse.time', mouse.time);
    psychoJS.experiment.addData('mouse.clicked_name', mouse.clicked_name);
    
    // the Routine "corsi_present" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var feedbackMaxDurationReached;
var feedbackMaxDuration;
var feedbackComponents;
function feedbackRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'feedback' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    feedbackClock.reset(routineTimer.getTime());
    routineTimer.add(1.000000);
    feedbackMaxDurationReached = false;
    // update component parameters for each repeat
    fb_2.setText((("\u0e04\u0e38\u0e13\u0e1e\u0e1a\u0e40\u0e1b\u0e49\u0e32\u0e2b\u0e21\u0e32\u0e22\u0e43\u0e19 " + Number.parseInt((mouse.time.slice((- 1))[0] * 1000)).toString()) + "ms"));
    trial_counter.setText(((trials.thisN.toString() + "/") + trials.nTotal.toString()));
    // Run 'Begin Routine' code from track_rt_2
    if ((correct === 1)) {
        feedback_text = "ถูกต้อง!";
    } else {
        if ((correct === 0)) {
            feedback_text = "ผิด!";
        }
    }
    FB_2.setText(feedback_text);
    feedbackMaxDuration = null
    // keep track of which components have finished
    feedbackComponents = [];
    feedbackComponents.push(fb_2);
    feedbackComponents.push(trial_counter);
    feedbackComponents.push(FB_2);
    
    feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function feedbackRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'feedback' ---
    // get current time
    t = feedbackClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fb_2* updates
    if (t >= 0.0 && fb_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fb_2.tStart = t;  // (not accounting for frame time here)
      fb_2.frameNStart = frameN;  // exact frame index
      
      fb_2.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (fb_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      fb_2.setAutoDraw(false);
    }
    
    
    // *trial_counter* updates
    if (t >= 0.0 && trial_counter.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      trial_counter.tStart = t;  // (not accounting for frame time here)
      trial_counter.frameNStart = frameN;  // exact frame index
      
      trial_counter.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (trial_counter.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      trial_counter.setAutoDraw(false);
    }
    
    
    // *FB_2* updates
    if (t >= 0.0 && FB_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      FB_2.tStart = t;  // (not accounting for frame time here)
      FB_2.frameNStart = frameN;  // exact frame index
      
      FB_2.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (FB_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      FB_2.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function feedbackRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'feedback' ---
    feedbackComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // Run 'End Routine' code from track_rt_2
    rts.push(mouse.time.slice((- 1))[0]);
    n_round_1 += 1;
    if ((n_round_1 > 1)) {
        trials.finished = true;
    }
    
    if (feedbackMaxDurationReached) {
        feedbackClock.add(feedbackMaxDuration);
    } else {
        feedbackClock.add(1.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var endMaxDurationReached;
var endMaxDuration;
var endComponents;
function endRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'end' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    endClock.reset();
    routineTimer.reset();
    endMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('end.started', globalClock.getTime());
    endMaxDuration = null
    // keep track of which components have finished
    endComponents = [];
    
    endComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function endRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'end' ---
    // get current time
    t = endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    endComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function endRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'end' ---
    endComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('end.stopped', globalClock.getTime());
    // the Routine "end" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
